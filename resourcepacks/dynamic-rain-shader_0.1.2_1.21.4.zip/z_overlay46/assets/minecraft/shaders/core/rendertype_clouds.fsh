#version 150
//cloud transparency

#moj_import <minecraft:fog.glsl>

in float vertexDistance;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
	//self declared fog values
	float fogStart = 200.0;
	float fogEnd = 300.0;
	float fogValue = 0.0;

	vec4 newColor = vertexColor;
	newColor.a = 0.40;   //makes clouds transparent
	//creates fog
	if (vertexDistance > fogStart) { fogValue = vertexDistance < fogEnd ? smoothstep(fogStart, fogEnd, vertexDistance) : 1.0; }
	//manual linear_fog method
    fragColor = newColor * vec4(1.0, 1.0, 1.0, 1.0 - fogValue) * vec4(1.0, 1.0, 1.0, 0.75);
}
